const User = require("../Models/UserModel");

const createUser = async (req, res, next) => {
    try {
        const user = await User.create({ ...req.body });
        res.status(200).json({
            data: user,
            message: "User created successfully",
        });
    } catch (error) {
        next(error);
    }
};

async function readUser(req, res, next) {
    try {
        const user = await User.find({})

        res.status(200).json({
            data: user,
            message: "User read successfully",
        });
    } catch (error) {
        next(error);
    }
}


const updateUser = async (req, res, next) => {
    try {
        const user = await User.findByIdAndUpdate(
            { _id: req.params.id },
            { $set: { ...req.body } },
            {
                new: true,
                useFindAndModify: false,
            }
        );
        res.status(200).json({
            data: user, message: `Update Successfully!`
        });
    } catch (error) {
        next(error);
    }
};

const deleteUser = async (req, res, next) => {
    try {
        const user = await User.findByIdAndDelete({ _id: req.params.id });

        res.status(200).json({ data: user, message: `Update Successfully!` });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createUser,
    readUser,
    updateUser,
    deleteUser,
};
