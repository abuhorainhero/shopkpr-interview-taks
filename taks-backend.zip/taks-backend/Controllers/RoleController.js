const Role = require("../Models/RoleModel");

const createRole = async (req, res, next) => {
    try {
        const role = await Role.create({ ...req.body });
        res.status(200).json({
            data: role,
            message: "Role created successfully",
        });
    } catch (error) {
        next(error);
    }
};

async function readRole(req, res, next) {
    try {
        const role = await Role.find({})

        res.status(200).json({
            data: role,
            message: "Role read successfully",
        });
    } catch (error) {
        next(error);
    }
}


const updateRole = async (req, res, next) => {
    try {
        const role = await Role.findByIdAndUpdate(
            { _id: req.params.id },
            { $set: { ...req.body } },
            {
                new: true,
                useFindAndModify: false,
            }
        );
        res.status(200).json({
            data: role, message: `Update Successfully!`
        });
    } catch (error) {
        next(error);
    }
};

const deleteRole = async (req, res, next) => {
    try {
        const role = await Role.findByIdAndDelete({ _id: req.params.id });

        res.status(200).json({ data: role, message: `Update Successfully!` });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createRole,
    readRole,
    updateRole,
    deleteRole,
};
