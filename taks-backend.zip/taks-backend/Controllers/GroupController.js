const Group = require("../Models/GroupModel");

const createGroup = async (req, res, next) => {
    try {
        const group = await Group.create({ ...req.body });
        res.status(200).json({
            data: group,
            message: "Group created successfully",
        });
    } catch (error) {
        next(error);
    }
};

async function readGroup(req, res, next) {
    try {
        const group = await Group.find({})

        res.status(200).json({
            data: group,
            message: "Group read successfully",
        });
    } catch (error) {
        next(error);
    }
}


const updateGroup = async (req, res, next) => {
    try {
        const group = await Group.findByIdAndUpdate(
            { _id: req.params.id },
            { $set: { ...req.body } },
            {
                new: true,
                useFindAndModify: false,
            }
        );
        res.status(200).json({
            data: group, message: `Update Successfully!`
        });
    } catch (error) {
        next(error);
    }
};

const deleteGroup = async (req, res, next) => {
    try {
        const group = await Group.findByIdAndDelete({ _id: req.params.id });

        res.status(200).json({ data: group, message: `Update Successfully!` });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createGroup,
    readGroup,
    updateGroup,
    deleteGroup,
};
