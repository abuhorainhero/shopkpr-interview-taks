const express = require('express');
const router = express.Router();

const {
  createRole,
  readRole,
  updateRole,
  deleteRole,
} = require("../Controllers/RoleController");

router
  .post("/",  createRole)
  .get("/", readRole)
  .put("/:id", updateRole)
  .delete("/:id", deleteRole);


module.exports = router;
