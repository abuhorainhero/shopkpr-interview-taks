const express = require('express');
const router = express.Router();

const {
  createUser,
  readUser,
  updateUser,
  deleteUser,
} = require("../Controllers/UserController");

router
  .post("/",  createUser)
  .get("/", readUser)
  .put("/:id", updateUser)
  .delete("/:id", deleteUser);


module.exports = router;
