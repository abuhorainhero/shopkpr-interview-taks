const express = require('express');
const router = express.Router();

const {
  createGroup,
  readGroup,
  updateGroup,
  deleteGroup,
} = require("../Controllers/GroupController");

router
  .post("/",  createGroup)
  .get("/", readGroup)
  .put("/:id", updateGroup)
  .delete("/:id", deleteGroup);


module.exports = router;
