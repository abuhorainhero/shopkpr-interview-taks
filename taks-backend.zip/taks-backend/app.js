// Extranal imports
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
require("dotenv").config();
const cors = require("cors");

// internal imports
require("./db/db")
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/UserRouter');
const groupsRouter = require('./routes/GroupRouter');
const rolesRouter = require('./routes/RoleRouter');
const { notFoundHandler, errorHandler } = require('./Middleware/errorHandler');

const app = express();

app.use(logger('dev'));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/api/users', usersRouter);
app.use('/api/groups', groupsRouter);
app.use('/api/roles', rolesRouter)


// error handlers
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
