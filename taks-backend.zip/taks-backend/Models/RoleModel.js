const mongoose = require("mongoose");
const { Schema } = mongoose;

const RoleSchema = new Schema(
    {
        roleName: {
            type: String,
            required: true,
            trim: true,
        },
        description: {
            type: String,
            trim: true,
        },
    },
    {
        versionKey: false,
        timestamps: true,
    }
);


const Role = mongoose.model("Role", RoleSchema);

module.exports = Role;
