const mongoose = require("mongoose");
const { Schema } = mongoose;

const GroupSchema = new Schema(
    {
        groupName: {
            type: String,
            required: true,
            trim: true,
        },
        description: {
            type: String,
            trim: true,
        },
    },
    {
        versionKey: false,
        timestamps: true,
    }
);


const Group = mongoose.model("Group", GroupSchema);

module.exports = Group;
