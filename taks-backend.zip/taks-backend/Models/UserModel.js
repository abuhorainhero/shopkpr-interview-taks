const mongoose = require("mongoose");
const { Schema } = mongoose;

const UserSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    userName: {
      type: String,
      trim: true,
    },
    email: {
      type: String,
      trim: true,
      required: true,
    },
    details: {
        type: String,
        trim: true,
        default: "Lorem ipsum dolor sit amet provident veniam ea, nemo id praesentium accusantium et numquam earum quaerat aliquam in."
      },
      
    role: {
      type: String,
      trim: true,
      enum: ["user", "admin"],
      default: "user",
    },

  },
  {
    versionKey: false,
    timestamps: true,
  }
);


const User = mongoose.model("User", UserSchema);

module.exports = User;
