// mongoose :
const mongoose = require("mongoose");
const dbUrl = process.env.MONGODB_URL;

if (!dbUrl) {
  console.error("MOngo url not sat in env file");
  return new Error("MOngo url not sat in env file");
}

mongoose.connect(
  dbUrl,
  {
    useNewUrlParser: true,
  },
  (err) => {
    if (err) {
      console.error(`failed to connect using mongoose : ${err}`);
    } else {
      console.log(`connected to DATA_BASE server`);
    }
  }
);

module.exports = mongoose;